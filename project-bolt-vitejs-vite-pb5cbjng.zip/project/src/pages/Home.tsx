import { Link } from 'react-router-dom';

function Home() {
  return (
    <div>
      <section className="bg-gradient-to-r from-primary to-secondary text-white py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-5xl md:text-7xl font-bold mb-8 leading-tight">
              Transform Your Fitness Journey
            </h1>
            <p className="text-xl md:text-2xl mb-10 opacity-90">
              AI-powered workout equipment and nutrition guidance for tech-savvy individuals
            </p>
            <Link to="/services" className="btn bg-white text-primary hover:bg-opacity-90 hover:text-primary inline-flex items-center space-x-2">
              Explore Services
            </Link>
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <div className="card p-8">
              <h3 className="text-2xl font-bold mb-4 text-primary">Smart Equipment</h3>
              <p className="text-gray-600">
                AI-integrated fitness equipment with built-in screens for guided workouts
              </p>
            </div>
            <div className="card p-8">
              <h3 className="text-2xl font-bold mb-4 text-secondary">Online Consultation</h3>
              <p className="text-gray-600">
                Connect with certified trainers for personalized guidance
              </p>
            </div>
            <div className="card p-8">
              <h3 className="text-2xl font-bold mb-4 text-accent">Nutrition Excellence</h3>
              <p className="text-gray-600">
                AI-powered meal planning and expert nutrition consultation
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-light py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="section-title text-center">Featured Services</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            {[
              {
                title: "Smart Treadmill",
                price: "$1,499",
                image: "https://images.pexels.com/photos/4162451/pexels-photo-4162451.jpeg"
              },
              {
                title: "AI Resistance Trainer",
                price: "$899",
                image: "https://images.pexels.com/photos/4162488/pexels-photo-4162488.jpeg"
              }
            ].map((product, index) => (
              <div key={index} className="card overflow-hidden group">
                <img
                  src={product.image}
                  alt={product.title}
                  className="w-full h-56 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="p-8">
                  <h3 className="text-2xl font-bold mb-2 text-dark">{product.title}</h3>
                  <p className="text-primary text-xl font-semibold mb-6">{product.price}</p>
                  <button className="btn btn-primary w-full">Learn More</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default Home;