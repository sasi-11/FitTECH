function About() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-4xl font-bold text-center mb-8">About Fit|TECH</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <div>
          <h2 className="text-2xl font-semibold mb-4">Our Mission</h2>
          <p className="text-gray-600 mb-6">
            At Fit|TECH, we're revolutionizing the fitness industry by combining cutting-edge technology 
            with exercise equipment. Our mission is to make fitness accessible, engaging, and effective 
            for everyone, from tech-savvy professionals to senior citizens.
          </p>
          <p className="text-gray-600">
            We believe that everyone deserves access to quality fitness guidance, whether they're 
            working from home, living in remote areas, or prefer the convenience of home workouts.
          </p>
        </div>
        
        <div>
          <h2 className="text-2xl font-semibold mb-4">Why Choose Us?</h2>
          <ul className="space-y-4">
            <li className="flex items-start">
              <span className="text-primary font-bold mr-2">•</span>
              <span className="text-gray-600">AI-powered equipment with built-in guidance</span>
            </li>
            <li className="flex items-start">
              <span className="text-primary font-bold mr-2">•</span>
              <span className="text-gray-600">Specialized solutions for seniors and remote workers</span>
            </li>
            <li className="flex items-start">
              <span className="text-primary font-bold mr-2">•</span>
              <span className="text-gray-600">Professional online consultation services</span>
            </li>
            <li className="flex items-start">
              <span className="text-primary font-bold mr-2">•</span>
              <span className="text-gray-600">Portable and space-efficient equipment</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}

export default About;