function FAQ() {
  const faqs = [
    {
      question: "How does the AI guidance work?",
      answer: "Our equipment features built-in screens with AI technology that analyzes your movements in real-time, providing feedback and guidance to ensure proper form and technique."
    },
    {
      question: "Is the equipment suitable for seniors?",
      answer: "Yes, we offer specially designed equipment for seniors that is easy to use, portable, and comes with clear AI guidance for safe exercise and physiotherapy routines."
    },
    {
      question: "How do I book an online consultation?",
      answer: "You can book a consultation through our website by selecting the 'Book Consultation' option in our Services page and choosing your preferred time slot with our certified trainers."
    },
    {
      question: "What makes your equipment different from regular gym equipment?",
      answer: "Our equipment integrates smart technology with traditional fitness equipment, providing real-time guidance, progress tracking, and personalized workout plans without requiring a human trainer."
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-4xl font-bold text-center mb-12">Frequently Asked Questions</h1>
      
      <div className="space-y-6">
        {faqs.map((faq, index) => (
          <div key={index} className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-bold mb-4">{faq.question}</h2>
            <p className="text-gray-600">{faq.answer}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default FAQ;