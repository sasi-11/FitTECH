function Services() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-4xl font-bold text-center mb-12">Our Services</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-bold mb-4">Smart Equipment</h2>
          <p className="text-gray-600 mb-4">
            Advanced fitness equipment with built-in screens and AI guidance for perfect form and technique.
          </p>
          <button className="btn btn-primary">View Equipment</button>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-bold mb-4">Online Consultation</h2>
          <p className="text-gray-600 mb-4">
            Book virtual sessions with certified trainers for personalized fitness advice and guidance.
          </p>
          <button className="btn btn-primary">Book Consultation</button>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-bold mb-4">Home Physiotherapy</h2>
          <p className="text-gray-600 mb-4">
            Portable equipment with AI guidance for senior citizens requiring physiotherapy at home.
          </p>
          <button className="btn btn-primary">Learn More</button>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-bold mb-4">AI Nutrition Consulting</h2>
          <p className="text-gray-600 mb-4">
            Get personalized meal plans and nutrition advice powered by our advanced AI system. Track your macros, receive real-time recommendations, and optimize your diet for your fitness goals.
          </p>
          <button className="btn btn-primary">Start Planning</button>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-bold mb-4">Expert Nutrition Guidance</h2>
          <p className="text-gray-600 mb-4">
            Connect with our certified nutrition specialists with 10+ years of experience. Get customized meal plans, supplement advice, and ongoing support for your fitness journey.
          </p>
          <button className="btn btn-primary">Meet Our Experts</button>
        </div>
      </div>
    </div>
  );
}

export default Services;