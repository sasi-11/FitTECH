function Blogs() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-4xl font-bold text-center mb-12">Fitness Blog</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {[
          {
            title: "Tech-Savvy Fitness: A Guide for Remote Workers",
            date: "March 15, 2024",
            image: "https://images.pexels.com/photos/4498606/pexels-photo-4498606.jpeg"
          },
          {
            title: "Senior Fitness: Staying Active with Smart Equipment",
            date: "March 12, 2024",
            image: "https://images.pexels.com/photos/7991662/pexels-photo-7991662.jpeg"
          },
          {
            title: "The Future of Home Workouts with AI",
            date: "March 10, 2024",
            image: "https://images.pexels.com/photos/4325478/pexels-photo-4325478.jpeg"
          }
        ].map((post, index) => (
          <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden">
            <img
              src={post.image}
              alt={post.title}
              className="w-full h-48 object-cover"
            />
            <div className="p-6">
              <p className="text-gray-500 text-sm mb-2">{post.date}</p>
              <h2 className="text-xl font-bold mb-4">{post.title}</h2>
              <button className="btn btn-primary">Read More</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Blogs;